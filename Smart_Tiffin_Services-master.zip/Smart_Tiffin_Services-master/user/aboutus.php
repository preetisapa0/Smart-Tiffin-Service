<!-- Mirrored from webstrot.com/html/lunchbox/lunchbox/about-us.html by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 17 Aug 2026 17:00:14 GMT -->

<head>
    <meta charset="utf-8">
    <title>Lunch Box - About Us</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <link rel="shortcut icon" type="image/png" href="images/logo/favicon.ico">
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="css/fonts.css">
    <link rel="stylesheet" href="css/font-awesome-6.css">
    <link rel="stylesheet" type="text/css" href="css/grt-youtube-popup.css">
    <link rel="stylesheet" type="text/css" href="css/owl.carousel.min.css">
    <link rel="stylesheet" type="text/css" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" type="text/css" href="css/animate.css">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="stylesheet" type="text/css" href="css/responsive.css">
</head>

<body>
    <main class="innerPage">

        <!--Preloader start-->
        <div class="preloader" id="status">
            <div class="preloaderInner" id="preloader">
                <div class="loaderGroup">
                    <div class="loaderContent">
                        <div class="loading" data-loading-text="LunchBox..."></div>
                    </div>
                </div>
            </div>
        </div>
        <!--Preloader end-->

        <!--header start-->
        <?php
      include("header.php");
?>
        <!--header end-->

        <!-- search start -->
        <div class="searchBox">
            <div class="searchBoxCard">
                <a href="javascript:void(0);" class="searchBoxClose">
                    <i class="fa-solid fa-xmark"></i>
                </a>
                <div class="searchBoxInner">
                    <div class="searchBoxLogo">
                        <img src="images/logo/logo-white.png" alt="search" class="img-fluid">
                    </div>
                    <div class="searchBoxForm">
                        <div class="input-group">
                            <input type="text" class="form-control" placeholder="Search...">
                            <button type="button" class="btn btnSecondary">Search</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- search end -->

        <!-- search start -->
        <div class="searchBox">
            <div class="searchBoxCard">
                <a href="javascript:void(0);" class="searchBoxClose">
                    <i class="fa-solid fa-xmark"></i>
                </a>
                <div class="searchBoxInner">
                    <div class="searchBoxLogo">
                        <img src="images/logo/logo-white.png" alt="search" class="img-fluid">
                    </div>
                    <div class="searchBoxForm">
                        <div class="input-group">
                            <input type="text" class="form-control" placeholder="Search...">
                            <button type="button" class="btn btnSecondary">Search</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- search end -->

        <!-- banner start-->
        <section class="w-100 clearfix innerPageBanner" id="innerPageBanner">
            <div class="container">
                <div class="innerPageBannerInner">
                    <div class="innerPageBannerImgLeft">
                        <img src="images/img24.png" alt="banner-img" class="img-fluid">
                    </div>
                    <div class="innerPageBannerContent">
                        <h1>About <span>Us</span></h1>

                    </div>
                    <div class="innerPageBannerImgRight">
                        <img src="images/img23.png" alt="banner-img" class="img-fluid">
                    </div>
                </div>
            </div>
        </section>
        <!-- banner end-->

        <!--Customer Says Start-->
        <section class="w-100 clearfix informationInto" id="informationInto">
            <div class="container">
                <div class="informationIntoInner">
                    <div class="informationIntoRow">
                        <div class="informationIntoCol">
                            <div class="informationIntoImg">
                                <div class="informationIntoImgInner">
                                    <img src="images/img25.png" alt="img" class="img-fluid girlImg">
                                </div>
                            </div>
                        </div>
                        <div class="howItWorkCol">
                            <div class="howItWorkContent">
                                <div class="commonHeading headingLeft">
                                    <h4>Information Into <span>Actionable</span></h4>
                                    <p>24Seven is the one-stop-shop for all customer needs, whatever the time of day
                                        or night. Customers can find the best global brands on the shelves to meet their
                                        daily
                                        needs like groceries, snacks, a wide variety of beverages, personal care
                                        products, and
                                        even Colorbar - our own brand of premium cosmetics. The ready-to-eat food
                                        counters feature
                                        the best quality of local & international cuisines, made within our very own
                                        state-of-the-art central kitchen.</p>

                                    <p>In addition to a wide variety of products, customers can utilize a plethora of
                                        in-house
                                        services, from instant photo development, bill payments, mobile phone recharges
                                        to even
                                        purchasing exclusive event tickets & passes and other offerings. 24 Seven
                                        believes in
                                        being. 24Seven Convenience Stores can be found illuminating dark streets at over
                                        120
                                        locations across Delhi & NCR, with plans to expand to at least 500 stores across
                                        the
                                        nation, with the introduction of a franchising model.</p>

                                    <p>one-stop-shop for all customer needs, whatever the time of day
                                        or night. Customers can find the best global brands on the shelves to meet their
                                        daily
                                        needs like groceries, snacks, a wide variety of beverages, personal care
                                        products, and
                                        even Colorbar - our own brand of premium cosmetics. The ready-to-eat food
                                        counters feature
                                        the best quality of local & international cuisines, made within our very own
                                        state-of-the-art central kitchen.</p>

                                    <p>In addition to a wide variety of products, customers can utilize a plethora of
                                        in-house
                                        services, from instant photo development, bill payments, mobile phone recharges
                                        to even
                                        purchasing exclusive event tickets & passes and other offerings. 24 Seven
                                        believes in
                                        being. 24Seven Convenience Stores can be found illuminating dark streets at over
                                        120
                                        locations across Delhi & NCR, with plans to expand to at least 500 stores across
                                        the
                                        nation, with the introduction of a franchising model.</p>
                                </div>

                                <div class="specialDishBtnGroup">
                                    <div class="specialDishGetStartedBtn">
                                        <a href="javascript:void(0);" class="btn btnPrimary">Get Started</a>
                                    </div>
                                    <div class="specialDishWatchVideoBtn">
                                        <a href="javascript:void(0);" class="flVideo watchNow youtube-link"
                                            data-youtube-id="ZrGzRmcIFcU">
                                            <span class="playIcon">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="15" height="18"
                                                    viewBox="0 0 15 18" fill="none">
                                                    <path d="M1 1V17L14 9L1 1Z" stroke="#FFA31E" stroke-width="1.5"
                                                        stroke-linecap="round" stroke-linejoin="round"></path>
                                                </svg>
                                            </span>
                                            <span>Watch video</span>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--Customer Says End-->

        <!--How It Work Start-->
        <section class="w-100 clearfix howItWork howItWorkAbout" id="howItWorkAbout">
            <div class="container">
                <div class="howItWorkInner">
                    <div class="commonHeading headingCenter">
                        <h4>How <span>It</span> Work</h4>
                        <p class="mb-0">The state-of-the art facility has automated machinery, is installed with
                            rust-free
                            pipelines and faucets and uses only RO treated water.</p>
                    </div>
                    <div class="row">
                        <div class="col-md-4">
                            <div class="howItWorkItem">
                                <div class="howItWorkIcon">
                                    <svg fill="none" width="77" height="65" viewBox="0 0 77 65">
                                        <path fill="#FFA31E" fill-rule="evenodd"
                                            d="M33.394 55.568c-.223 0-.536-.134-.76-.313L18.82 41.44c-1.117-1.117-1.743-2.637-1.743-4.157 0-1.565.626-3.04 1.743-4.158 2.28-2.235 5.99-2.235 8.226 0l5.23 5.186V15.334c0-3.219 2.593-5.901 5.901-5.901 3.22 0 5.901 2.637 5.901 5.9v16.14h8.986c5.767 0 10.46 4.693 10.46 10.46V54.45c0 .626-.536 1.118-1.117 1.118a1.107 1.107 0 01-1.117-1.118V41.933c0-4.56-3.756-8.27-8.27-8.27H42.96a1.107 1.107 0 01-1.117-1.118V15.334c0-2.012-1.699-3.71-3.71-3.71-2.057 0-3.755 1.698-3.755 3.71v25.57c0 .448-.224.85-.671 1.029-.447.179-.85.045-1.162-.268l-6.974-7.019c-1.43-1.43-3.8-1.43-5.23 0-.671.715-1.029 1.61-1.029 2.638 0 .983.358 1.922 1.118 2.593l13.724 13.858c.402.402.402 1.117 0 1.52a1.167 1.167 0 01-.76.313z"
                                            clip-rule="evenodd" />
                                        <path fill="#FFA31E" fill-rule="evenodd"
                                            d="M62.318 65H33.394a1.107 1.107 0 01-1.117-1.117V54.45c0-.626.491-1.118 1.117-1.118h28.924c.626 0 1.117.492 1.117 1.118v9.432c0 .626-.491 1.118-1.117 1.118zm-27.851-2.146H61.2v-7.286H34.467v7.286zM42.96 19.76c-.357 0-.76-.18-.938-.582-.313-.492-.134-1.162.358-1.475 2.503-1.475 4.157-3.219 4.157-7.197 0-3.8-3.71-8.315-8.36-8.315a8.3 8.3 0 00-8.314 8.314 8.322 8.322 0 003.218 6.572c.313.268.626.447.939.626.492.313.67.983.358 1.475-.313.537-.984.715-1.476.402-.357-.268-.804-.491-1.162-.804-2.548-2.012-3.979-5.052-3.979-8.27C27.761 4.738 32.455 0 38.222 0c5.99 0 10.55 5.677 10.55 10.505 0 5.276-2.637 7.556-5.185 9.075-.269.135-.447.18-.626.18zM10.55 21.056C4.74 21.056 0 16.362 0 10.55 0 4.783 4.739.09 10.55.09c5.767 0 10.506 4.693 10.506 10.46 0 5.812-4.739 10.506-10.506 10.506zm0-18.866c-4.649 0-8.36 3.71-8.36 8.36 0 4.694 3.756 8.36 8.36 8.36 4.605 0 8.315-3.755 8.315-8.36 0-4.56-3.71-8.36-8.315-8.36zM65.805 21.056c-5.767 0-10.506-4.694-10.506-10.506C55.3 4.783 60.038.09 65.805.09 71.57.09 76.31 4.782 76.31 10.55c0 5.812-4.649 10.506-10.505 10.506zm0-18.866a8.3 8.3 0 00-8.315 8.315 8.3 8.3 0 008.315 8.315 8.3 8.3 0 008.315-8.315 8.271 8.271 0 00-8.315-8.315z"
                                            clip-rule="evenodd" />
                                        <path fill="#FFA31E" fill-rule="evenodd"
                                            d="M8.94 14.708c-.312 0-.58-.09-.76-.269l-2.95-2.995a1.08 1.08 0 010-1.564 1.029 1.029 0 011.52 0l2.19 2.235 5.32-5.41a1.165 1.165 0 011.565 0 1.08 1.08 0 010 1.565l-6.124 6.17a1.128 1.128 0 01-.76.268zM70.41 16.138c-.269 0-.582-.089-.76-.313l-9.12-9.03a1.08 1.08 0 010-1.564 1.08 1.08 0 011.564 0l9.12 9.075a1.029 1.029 0 010 1.52 1.315 1.315 0 01-.805.312z"
                                            clip-rule="evenodd" />
                                        <path fill="#FFA31E" fill-rule="evenodd"
                                            d="M61.29 16.138c-.269 0-.582-.089-.76-.313a1.03 1.03 0 010-1.52l9.12-9.074a1.08 1.08 0 011.564 0 1.08 1.08 0 010 1.564l-9.21 9.03c-.178.224-.49.313-.714.313z"
                                            clip-rule="evenodd" />
                                    </svg>
                                </div>
                                <div class="howItWorkContent">
                                    <h4>Choose Option</h4>
                                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse luctus nec
                                        elit in
                                        vulputate.</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="howItWorkItem">
                                <div class="howItWorkIcon">
                                    <svg fill="none" width="76" height="65" viewBox="0 0 76 65">
                                        <path fill="#FFA31E" fill-rule="evenodd"
                                            d="M37.597 65c-7.353 0-14.412-2.5-20.148-7.059-5.588-4.412-9.558-10.588-11.323-17.5-.147-.588.294-1.176.735-1.323.589-.147 1.177.294 1.324.735C11.567 53.529 23.626 62.94 37.597 62.94c13.97 0 26.029-9.412 29.411-23.088.147-.588.736-.882 1.324-.735.441.147.882.735.735 1.323-1.764 6.912-5.735 13.088-11.323 17.5C51.86 62.5 44.95 65 37.597 65zm30.44-39.118c-.44 0-.882-.294-1.029-.735C63.626 11.471 51.568 2.06 37.597 2.06c-13.971 0-26.03 9.412-29.412 23.088-.147.441-.735.882-1.324.735-.44-.147-.882-.735-.735-1.323 1.765-6.912 5.735-13.088 11.323-17.5C23.186 2.353 30.245 0 37.597 0S51.86 2.353 57.744 7.059c5.588 4.412 9.558 10.588 11.323 17.5.147.588-.294 1.176-.735 1.323h-.294z"
                                            clip-rule="evenodd" />
                                        <path fill="#FFA31E" fill-rule="evenodd"
                                            d="M13.185 41.177H.979c-.441 0-.735-.294-.882-.588-.147-.295-.147-.736.147-1.03l6.176-7.941a.809.809 0 01.735-.441c.295 0 .589.147.883.44l6.03 7.942c.146.294.146.735 0 1.03-.148.294-.442.588-.883.588zm-10.147-2.06h8.088l-3.97-5.293-4.118 5.294zM68.038 33.824c-.294 0-.588-.147-.883-.441l-6.029-7.942c-.147-.294-.294-.735 0-1.029.147-.441.441-.588.882-.588h12.206c.441 0 .736.294.883.588.147.294.147.735-.147 1.03l-6.177 7.94a.809.809 0 01-.735.442zm-3.97-7.941l3.97 5.294 4.117-5.294h-8.088z"
                                            clip-rule="evenodd" />
                                        <path fill="#FFA31E"
                                            d="M29.2 19.175l-.143-.143c-.355-.355-.498-.498-.498-.782 0-.356.143-.427.498-.783l.498-.498c.214-.285.214-.64-.07-.854-.285-.213-.641-.213-.854.071l-.427.427c-.427.427-.854.854-.854 1.708s.427 1.28.854 1.708l.142.142c.427.356.711.64.711 1.28 0 .712-.355 1.14-.782 1.566l-.143.142c-.213.285-.213.64.072.854.142.071.284.142.427.142a.769.769 0 00.498-.213l.142-.142c.498-.498 1.138-1.21 1.138-2.42-.07-1.21-.711-1.778-1.21-2.205zM37.88 16.4l-.142-.142c-.356-.356-.498-.498-.498-.783 0-.356.142-.427.498-.783l.498-.498c.213-.284.213-.64-.071-.854-.285-.213-.64-.213-.854.072l-.427.426c-.427.427-.854.854-.854 1.708s.427 1.28.854 1.708l.142.142c.427.356.712.64.712 1.28 0 .712-.356 1.14-.783 1.566l-.142.142c-.214.285-.214.64.071.854.142.071.285.143.427.143a.769.769 0 00.498-.214l.142-.142c.498-.498 1.139-1.21 1.139-2.42-.071-1.209-.712-1.778-1.21-2.205zM46.632 19.175l-.142-.143c-.356-.355-.498-.498-.498-.782 0-.356.142-.427.498-.783l.498-.498c.213-.285.213-.64-.072-.854-.284-.213-.64-.213-.853.071l-.427.427c-.427.427-.854.854-.854 1.708s.427 1.28.854 1.708l.142.142c.427.356.712.64.712 1.28 0 .712-.356 1.14-.783 1.566l-.142.142c-.214.285-.214.64.07.854.143.071.285.142.428.142a.769.769 0 00.498-.213l.142-.142c.498-.498 1.139-1.21 1.139-2.42-.143-1.21-.783-1.778-1.21-2.205zM57.874 45.074H17.175a.638.638 0 00-.64.64v1.495a3.006 3.006 0 002.988 2.988h36.003a3.006 3.006 0 002.988-2.988v-1.494a.638.638 0 00-.64-.64zm-.64 2.135c0 .996-.783 1.778-1.78 1.778H19.524a1.761 1.761 0 01-1.779-1.778v-.854h39.49v.854zM48.838 31.698c-2.49-2.42-5.693-3.914-9.037-4.412l1.21-1.21c.356-.355.498-.924.284-1.422-.213-.498-.64-.783-1.21-.783h-5.122c-.498 0-.996.285-1.21.783-.213.498-.07.996.285 1.423l1.21 1.21a16.64 16.64 0 00-9.108 4.41 16.083 16.083 0 00-4.98 11.1c0 .356.284.64.569.64.355 0 .64-.284.64-.569a14.776 14.776 0 014.625-10.245c2.633-2.562 6.048-3.985 9.605-4.198H38.307c3.629.213 6.973 1.636 9.606 4.198a14.776 14.776 0 014.625 10.245c0 .356.284.64.64.57.356 0 .64-.285.57-.64-.072-4.27-1.85-8.183-4.91-11.1zm-10.673-4.554h-1.28l-1.922-1.921h5.123l-1.921 1.92z" />
                                        <path stroke="#FFA31E" stroke-width=".5"
                                            d="M29.2 19.175l-.143-.143c-.355-.355-.498-.498-.498-.782 0-.356.143-.427.498-.783l.498-.498c.214-.285.214-.64-.07-.854-.285-.213-.641-.213-.854.071l-.427.427c-.427.427-.854.854-.854 1.708s.427 1.28.854 1.708l.142.142c.427.356.711.64.711 1.28 0 .712-.355 1.14-.782 1.566l-.143.142c-.213.285-.213.64.072.854.142.071.284.142.427.142a.769.769 0 00.498-.213l.142-.142c.498-.498 1.138-1.21 1.138-2.42-.07-1.21-.711-1.778-1.21-2.205zM37.88 16.4l-.142-.142c-.356-.356-.498-.498-.498-.783 0-.356.142-.427.498-.783l.498-.498c.213-.284.213-.64-.071-.854-.285-.213-.64-.213-.854.072l-.427.426c-.427.427-.854.854-.854 1.708s.427 1.28.854 1.708l.142.142c.427.356.712.64.712 1.28 0 .712-.356 1.14-.783 1.566l-.142.142c-.214.285-.214.64.071.854.142.071.285.143.427.143a.769.769 0 00.498-.214l.142-.142c.498-.498 1.139-1.21 1.139-2.42-.071-1.209-.712-1.778-1.21-2.205zM46.632 19.175l-.142-.143c-.356-.355-.498-.498-.498-.782 0-.356.142-.427.498-.783l.498-.498c.213-.285.213-.64-.072-.854-.284-.213-.64-.213-.853.071l-.427.427c-.427.427-.854.854-.854 1.708s.427 1.28.854 1.708l.142.142c.427.356.712.64.712 1.28 0 .712-.356 1.14-.783 1.566l-.142.142c-.214.285-.214.64.07.854.143.071.285.142.428.142a.769.769 0 00.498-.213l.142-.142c.498-.498 1.139-1.21 1.139-2.42-.143-1.21-.783-1.778-1.21-2.205zM57.874 45.074H17.175a.638.638 0 00-.64.64v1.495a3.006 3.006 0 002.988 2.988h36.003a3.006 3.006 0 002.988-2.988v-1.494a.638.638 0 00-.64-.64zm-.64 2.135c0 .996-.783 1.778-1.78 1.778H19.524a1.761 1.761 0 01-1.779-1.778v-.854h39.49v.854zM48.838 31.698c-2.49-2.42-5.693-3.914-9.037-4.412l1.21-1.21c.356-.355.498-.924.284-1.422-.213-.498-.64-.783-1.21-.783h-5.122c-.498 0-.996.285-1.21.783-.213.498-.07.996.285 1.423l1.21 1.21a16.64 16.64 0 00-9.108 4.41 16.083 16.083 0 00-4.98 11.1c0 .356.284.64.569.64.355 0 .64-.284.64-.569a14.776 14.776 0 014.625-10.245c2.633-2.562 6.048-3.985 9.605-4.198H38.307c3.629.213 6.973 1.636 9.606 4.198a14.776 14.776 0 014.625 10.245c0 .356.284.64.64.57.356 0 .64-.285.57-.64-.072-4.27-1.85-8.183-4.91-11.1zm-10.673-4.554h-1.28l-1.922-1.921h5.123l-1.921 1.92z" />
                                    </svg>
                                </div>
                                <div class="howItWorkContent">
                                    <h4>Order In Process</h4>
                                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse luctus nec
                                        elit in
                                        vulputate.</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="howItWorkItem">
                                <div class="howItWorkIcon">
                                    <svg fill="none" width="80" height="65" viewBox="0 0 80 65">
                                        <path fill="#FFA31E"
                                            d="M77.917 40H75c-.417-15.917-12.5-29-28-31 .833-.917 1.417-2.25 1.417-3.583C48.417 2.417 46 0 43 0s-5.5 2.417-5.5 5.417c0 1.416.5 2.666 1.417 3.583-15.584 2-27.667 15.083-28.084 31h-3.75c-.666 0-1.25.583-1.25 1.25s.584 1.25 1.25 1.25h11.5A3.621 3.621 0 0118 43c-2.917 2.917-3.833 6.833-2.25 9.5H1.25c-.667 0-1.25.583-1.25 1.25S.583 55 1.25 55h19.167C22.583 55 25 53.917 27 52c2.917-2.917 3.833-6.833 2.25-9.5h31.833a3.621 3.621 0 01-.583.5c-2.917 2.917-3.833 6.917-2.25 9.5h-9.5c-.667 0-1.25.583-1.25 1.25S48.083 55 48.75 55h14.167c2.166 0 4.583-1.083 6.583-3 2.917-2.917 3.833-6.917 2.25-9.5h6.167c.666 0 1.25-.583 1.25-1.25S78.583 40 77.917 40zm-35-37.5c1.583 0 2.916 1.333 2.916 2.917 0 1.583-1.333 2.916-2.916 2.916C41.333 8.333 40 7 40 5.417 40 3.833 41.333 2.5 42.917 2.5zM26.75 43.25c1.5 1.5.75 4.667-1.5 6.917s-5.5 3-6.917 1.5c-1.5-1.5-.75-4.667 1.5-6.917 1.5-1.5 3.334-2.25 4.834-2.25.75 0 1.5.25 2.083.75zM25 40H13.333c.417-15.917 13.5-28.75 29.584-28.75C58.917 11.25 72 24.083 72.5 40H25zm44.25 3.25c1.5 1.5.75 4.667-1.5 6.917s-5.5 3-6.917 1.5c-1.5-1.5-.75-4.667 1.5-6.917 1.5-1.5 3.334-2.25 4.834-2.25.75 0 1.5.25 2.083.75z" />
                                        <path fill="#FFA31E"
                                            d="M36.167 17.167c-6.917 2-12.667 6.916-15.667 13.5-.25.666 0 1.333.583 1.666.167.084.334.084.5.084.5 0 .917-.25 1.167-.75a21.917 21.917 0 0114.083-12.084c.667-.166 1.084-.916.834-1.583-.084-.583-.834-1-1.5-.833zM52.083 62.5H18.75c-.667 0-1.25.583-1.25 1.25S18.083 65 18.75 65h33.333c.667 0 1.25-.583 1.25-1.25s-.583-1.25-1.25-1.25z" />
                                    </svg>
                                </div>
                                <div class="howItWorkContent">
                                    <h4>Delivery</h4>
                                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse luctus nec
                                        elit in
                                        vulputate.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--How It Work End-->

        <!--Video Start-->
        <!-- <section class="aboutUsVideo" id="aboutUsVideo">
            <div class="container">
                <h2 class="d-none">About Us</h2>
                <div class="aboutUsVideoInner">
                    <div class="aboutUsVideoContainer">
                        <video id="aboutUsBgVideo" class="aboutUsBgVideo" autoplay loop muted>
                            <source src="video/video.mp4" type="video/mp4">
                        </video>
                        <button id="playPauseButton" class="playPauseButton"><i class="fa-solid fa-pause"></i></button>
                    </div>

                    <div class="aboutUsVideoContent">
                        <p>Certified as one of the best commissaries in the world by The Foundation Food Safety System
                            Certification 22000 (FSSC 22000), our commissary is compliant with international and
                            independent
                            standards to maintain the highest levels of hygiene and sanitization while handling your
                            food.</p>
                    </div>
                </div>
            </div>
            </section>
            <!--Video End-->

        <!--We"ve Won Awards Start-->
        <!-- <section class="weWonAwards" id="weWonAwards">
            <div class="container">
                <div class="weWonAwardsInner">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="weWonAwardsContent">
                                <div class="commonHeading headingLeft">
                                    <h4>We"ve Won <span>Awards</span></h4>
                                    <p>Certified as one of the best commissaries in the world by The Foundation Food
                                        Safety
                                        System Certification 22000 (FSSC 22000), our commissary is compliant with
                                        international
                                        and independent standards to maintain the highest levels of hygiene and
                                        sanitization while
                                        handling your food.</p>

                                    <p>With contact-less preparations to temperature controlled packaging and
                                        transportation of
                                        food, you just need to sit back and relax, enjoy fresh and safe food at a
                                        24Seven near you
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="weWonAwardsImg">
                                <img src="images/award.png" alt="award" class="img-fluid">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section> -->
        <!--We"ve Won Awards End-->

        <!--Trusted by users Start-->
        <!-- <section class="w-100 clearfix trustedUsers" id="trustedUsers">
            <div class="container">
                <div class="trustedUsersInner">
                    <div class="commonHeading headingCenter">
                        <h2 class="d-none">Trusted Users</h2>
                        <p class="mb-0">Trusted by 45M+ users</p>
                    </div>
                    <div class="owl-carousel owl-theme trustedUsersCarousel">
                        <div class="item">
                            <div class="trustedUsersItem">
                                <a href="javascript:void(0);"><img src="images/partner1.png" alt="trusted-users"
                                        class="img-fluid"></a>
                            </div>
                        </div>
                        <div class="item">
                            <div class="trustedUsersItem">
                                <a href="javascript:void(0);"><img src="images/partner2.png" alt="trusted-users"
                                        class="img-fluid"></a>
                            </div>
                        </div>
                        <div class="item">
                            <div class="trustedUsersItem">
                                <a href="javascript:void(0);"><img src="images/partner3.png" alt="trusted-users"
                                        class="img-fluid"></a>
                            </div>
                        </div>
                        <div class="item">
                            <div class="trustedUsersItem">
                                <a href="javascript:void(0);"><img src="images/partner4.png" alt="trusted-users"
                                        class="img-fluid"></a>
                            </div>
                        </div>
                        <div class="item">
                            <div class="trustedUsersItem">
                                <a href="javascript:void(0);"><img src="images/partner5.png" alt="trusted-users"
                                        class="img-fluid"></a>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </section> -->
        <!--Trusted by users End-->

        <!--Footer Section Start-->
        <?php
   include("footer.php");
?>
        <!--Footer Section End-->

    </main>
    <script src="js/jquery-3.6.4.min.js"></script>
    <script src="js/bootstrap.bundle.min.js"></script>
    <script src="js/wow.min.js"></script>
    <script src="js/anime.min.js"></script>
    <script src="js/grt-youtube-popup.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/custom.js"></script>

    <script>
    $(".youtube-link").grtyoutube({
        autoPlay: true,
        theme: "dark",
    });
    </script>

    <script>
    const video = document.getElementById('aboutUsBgVideo');
    const playPauseButton = document.getElementById('playPauseButton');

    playPauseButton.addEventListener('click', () => {
        if (video.paused) {
            video.play();
            playPauseButton.innerHTML = '<i class="fa-solid fa-pause"></i>';
        } else {
            video.pause();
            playPauseButton.innerHTML = '<i class="fa-solid fa-play"></i>';
        }
    });
    </script>

</body>


<!-- Mirrored from webstrot.com/html/lunchbox/lunchbox/about-us.html by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 17 Aug 2026 17:00:15 GMT -->

</html>